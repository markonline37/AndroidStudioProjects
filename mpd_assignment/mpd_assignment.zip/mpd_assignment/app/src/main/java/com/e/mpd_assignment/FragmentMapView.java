package com.e.mpd_assignment;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import android.location.LocationListener;

import java.util.ArrayList;

public class FragmentMapView extends Fragment implements OnMapReadyCallback, MainActivity.MainActivityListener, View.OnClickListener, LocationListener  {

    private DataRepository dataRepository;
    private View view;

    private MapView mMapView;
    private static final String MAPVIEW_BUNDLE_KEY = "MapViewBundleKey";

    private GoogleMap map;

    private CheckBox incidentCheckbox;
    private CheckBox roadworksCheckbox;
    private CheckBox plannedRoadworksCheckbox;
    private CheckBox followMeCheckbox;
    private Button incidentButton;
    private Button roadworksButton;
    private Button plannedRoadworksButton;

    private ArrayList<Incident> storedIncidentArrayList;
    private ArrayList<Roadwork> storedRoadworkArrayList;
    private ArrayList<PlannedRoadwork> storedPlannedRoadworkArrayList;
    private ArrayList<Marker> incidentMarkers = new ArrayList<>();
    private ArrayList<Marker> roadworksMarkers = new ArrayList<>();
    private ArrayList<Marker> plannedRoadworksMarkers = new ArrayList<>();
    private Marker mymarker;
    private LatLng storedLatLng;

    private boolean gpsEnabled = false;
    private boolean initialLoad = true;

    //not exact, can update later.
    private LatLngBounds Scotland = new LatLngBounds(new LatLng(54.39, -7.83), new LatLng(58.66, -0.67));

    private LocationManager lm;
    private int MAP_UPDATE_TIME = 5000;

    Location location;

    private LatLng latLng;

    public FragmentMapView(DataRepository dataRepository, MainActivity main) {
        this.dataRepository = dataRepository;
        main.setMainActivityListener(this);
    }

    @Override
    public void updateMap() {
        System.out.println("updateMap called");
        this.redrawMap(false, false, false, false);
    }

    @Override
    public void onClick(View v) {
        if (v == incidentCheckbox) {
            if (incidentCheckbox.isChecked()) {
                dataRepository.setDefaultMapCheckboxViewIncident("checked");
                redrawMap(true, false, false, false);
            } else {
                dataRepository.setDefaultMapCheckboxViewIncident("unchecked");
                for(int i = 0, j = incidentMarkers.size(); i<j; i++){
                    incidentMarkers.get(i).remove();
                }
            }
        } else if (v == roadworksCheckbox) {
            if (roadworksCheckbox.isChecked()) {
                dataRepository.setDefaultMapCheckboxViewRoadworks("checked");
                redrawMap(false, true, false, false);
            } else {
                dataRepository.setDefaultMapCheckboxViewRoadworks("unchecked");
                for (int i = 0, j = roadworksMarkers.size(); i < j; i++) {
                    roadworksMarkers.get(i).remove();
                }
            }
        } else if (v == plannedRoadworksCheckbox) {
            if (plannedRoadworksCheckbox.isChecked()) {
                dataRepository.setDefaultMapCheckboxViewPlannedRoadworks("checked");
                redrawMap(false, false, true, false);
            } else {
                dataRepository.setDefaultMapCheckboxViewPlannedRoadworks("unchecked");
                for(int i = 0, j = plannedRoadworksMarkers.size(); i<j; i++){
                    plannedRoadworksMarkers.get(i).remove();
                }
            }
        } else if (v == followMeCheckbox) {
            if (followMeCheckbox.isChecked()) {
                dataRepository.setDefaultMapCheckboxViewFollowMe("checked");
                redrawMap(false, false, false, true);
            } else {
                dataRepository.setDefaultMapCheckboxViewFollowMe("unchecked");
            }
        } else if (v == incidentButton) {

        } else if (v == roadworksButton) {

        } else if (v == plannedRoadworksButton) {

        }
    }

    private void checkGPSPermissions(){
        if((ContextCompat.checkSelfPermission(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)){
            ActivityCompat.requestPermissions(this.getActivity(), new String[] { Manifest.permission.ACCESS_FINE_LOCATION }, 100);
        }else{
            gpsEnabled = true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 100) {
            gpsEnabled = true;
            setLocationListener();
        }else{
            gpsEnabled = false;
            //center of Scotland
            latLng = new LatLng(56.8169, -4.1827);
            Toast.makeText(GlobalContext.getContext(), "GPS Permissions not enabled, full functionality disabled", Toast.LENGTH_LONG).show();
        }
        redrawMap(false, false, false, false);
    }

    public void redrawMap( boolean incidentBoolean, boolean roadworksBoolean, boolean plannedRoadworksBoolean, boolean followMeBoolean) {
        if(initialLoad){
            initialLoad = false;
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
        }

        //if view incidents checkbox is checked
        if(dataRepository.getDefaultMapCheckboxViewIncident().equals("checked")){
            ArrayList<Incident> incidentArrayList = dataRepository.getIncidentArrayList();
            if(!incidentArrayList.equals(storedIncidentArrayList) || incidentBoolean){
                for(int i = 0, j = incidentMarkers.size(); i<j; i++){
                    incidentMarkers.get(i).remove();
                }
                Incident incident = null;
                double tempLat = 0;
                double tempLon = 0;
                String tempTitle = "";
                String tempDescription = "";
                for(int i = 0, j = incidentArrayList.size(); i<j; i++){
                    incident = incidentArrayList.get(i);
                    tempTitle = incident.getTitle();
                    tempDescription = incident.getDescription();
                    tempDescription = tempDescription.replace("<br />", "\n");
                    tempLat = incident.getLat();
                    tempLon = incident.getLon();
                    Marker marker = map.addMarker(new MarkerOptions().position(new LatLng(tempLat, tempLon)).title(tempTitle)
                            .snippet(tempDescription).icon(BitmapDescriptorFactory.fromResource(R.drawable.incidenticon)));
                    incidentMarkers.add(marker);
                }
                storedIncidentArrayList = incidentArrayList;
            }
        }
        //if view roadworks checkbox is checked
        if(dataRepository.getDefaultMapCheckboxViewRoadworks().equals("checked")){
            ArrayList<Roadwork> roadworkArrayList = dataRepository.getRoadworkArrayList();
            if(!roadworkArrayList.equals(storedRoadworkArrayList) || roadworksBoolean){
                for (int i = 0, j = roadworksMarkers.size(); i < j; i++) {
                    roadworksMarkers.get(i).remove();
                }
                Roadwork roadwork = null;
                double tempLat = 0;
                double tempLon = 0;
                String tempTitle = "";
                String tempDescription = "";
                for (int i = 0, j = roadworkArrayList.size(); i < j; i++) {
                    roadwork = roadworkArrayList.get(i);
                    tempTitle = roadwork.getTitle();
                    tempDescription = roadwork.getDescription();
                    tempDescription = tempDescription.replace("<br />", "\n");
                    tempLat = roadwork.getLat();
                    tempLon = roadwork.getLon();
                    Marker marker = null;
                    if(roadwork.getDelay().equalsIgnoreCase("No Delay")){
                        marker = map.addMarker(new MarkerOptions().position(new LatLng(tempLat, tempLon)).title(tempTitle).snippet(tempDescription)
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.roadworksiconnodelay)));
                    }else if(roadwork.getDelay().equalsIgnoreCase("Medium Delay")){
                        marker = map.addMarker(new MarkerOptions().position(new LatLng(tempLat, tempLon)).title(tempTitle).snippet(tempDescription)
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.roadworksiconmediumdelay)));
                    }else if(roadwork.getDelay().equalsIgnoreCase("High Delay")){
                        marker = map.addMarker(new MarkerOptions().position(new LatLng(tempLat, tempLon)).title(tempTitle).snippet(tempDescription)
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.roadworksiconhighdelay)));
                    }

                    roadworksMarkers.add(marker);
                }
                storedRoadworkArrayList = roadworkArrayList;
            }
        }
        //if view planned roadworks checkbox is checked
        if(dataRepository.getDefaultMapCheckboxViewPlannedRoadworks().equals("checked")){
            ArrayList<PlannedRoadwork> plannedRoadworkArrayList = dataRepository.getPlannedRoadworkArrayList();
            if(!plannedRoadworkArrayList.equals(storedPlannedRoadworkArrayList) || plannedRoadworksBoolean){
                for(int i = 0, j = plannedRoadworksMarkers.size(); i<j; i++){
                    plannedRoadworksMarkers.get(i).remove();
                }
                PlannedRoadwork plannedRoadwork = null;
                double tempLat = 0;
                double tempLon = 0;
                String tempTitle = "";
                String tempDescription = "";
                for(int i = 0, j = plannedRoadworkArrayList.size(); i<j; i++){
                    plannedRoadwork = plannedRoadworkArrayList.get(i);
                    tempTitle = plannedRoadwork.getTitle();
                    tempDescription = plannedRoadwork.getDescription();
                    tempDescription = tempDescription.replace("<br />", "\n");
                    tempLat = plannedRoadwork.getLat();
                    tempLon = plannedRoadwork.getLon();
                    Marker marker = map.addMarker(new MarkerOptions().position(new LatLng(tempLat, tempLon)).title(tempTitle).snippet(tempDescription)
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.plannedroadworksicon)));
                    plannedRoadworksMarkers.add(marker);
                }
                storedPlannedRoadworkArrayList = plannedRoadworkArrayList;
            }
        }
        if((!latLng.equals(storedLatLng) && gpsEnabled) || followMeBoolean){
            if(mymarker != null){
                mymarker.remove();
            }
            mymarker = map.addMarker(new MarkerOptions().position(latLng).icon(BitmapDescriptorFactory.fromResource(R.drawable.mymarker)));
            storedLatLng = latLng;
            if(followMeCheckbox.isChecked()){
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
            }
        }
    }

    @Override
    public void onAttach(Context context){
        super.onAttach(context);
        lm = (LocationManager) this.getActivity().getSystemService(Context.LOCATION_SERVICE);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){

        int orientation = this.getResources().getConfiguration().orientation;
        if(orientation == Configuration.ORIENTATION_PORTRAIT){
            //portrait
            view = inflater.inflate(R.layout.fragment_map, container, false);
        }else{
            //landscape
            view = inflater.inflate(R.layout.fragment_map_landscape, container, false);
        }

        initLoadView();

        mMapView = view.findViewById(R.id.mapView);
        mMapView.onCreate(savedInstanceState);

        mMapView.getMapAsync(this);


        checkGPSPermissions();
        if(gpsEnabled){
            setLocationListener();
        }

        return view;
    }

    private void setLocationListener(){
        try{
            if(gpsEnabled){
                if(ContextCompat.checkSelfPermission(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && lm != null){
                    if(lm.isProviderEnabled(LocationManager.GPS_PROVIDER)){
                        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, MAP_UPDATE_TIME, 0, this);
                    }
                    location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if(location != null) {
                        latLng = new LatLng(location.getLatitude(), location.getLongitude());
                    }else{
                        latLng = new LatLng(56.8169, -4.1827);
                    }
                }
            }
        }catch(Exception e){
            System.out.println("Error-FragmentMapView-updateLatLon(): "+e);
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        latLng = new LatLng(location.getLatitude(), location.getLongitude());
        redrawMap(false, false, false, false);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        //needed for location listener callback
    }

    @Override
    public void onProviderEnabled(String provider) {
        //needed for location listener callback
    }

    @Override
    public void onProviderDisabled(String provider) {
        //needed for location listener callback
    }

    //initialises the buttons and checkboxes (uses the stored settings for saved data) and sets the listeners
    private void initLoadView(){
        incidentCheckbox = view.findViewById(R.id.incidentsCheckbox);
        incidentCheckbox.setOnClickListener(this);
        roadworksCheckbox = view.findViewById(R.id.roadworksCheckbox);
        roadworksCheckbox.setOnClickListener(this);
        plannedRoadworksCheckbox = view.findViewById(R.id.plannedRoadworksCheckbox);
        plannedRoadworksCheckbox.setOnClickListener(this);
        followMeCheckbox = view.findViewById(R.id.followMeCheckbox);
        followMeCheckbox.setOnClickListener(this);
        incidentButton = view.findViewById(R.id.incidentsButton);
        incidentCheckbox.setOnClickListener(this);
        roadworksButton = view.findViewById(R.id.roadworksButton);
        roadworksButton.setOnClickListener(this);
        plannedRoadworksButton = view.findViewById(R.id.plannedRoadworksButton);
        plannedRoadworksButton.setOnClickListener(this);

        //sets the appropriate checked/unchecked for each checkbox based on last settings
        //data repository sets default values on first load
        if(dataRepository.getDefaultMapCheckboxViewIncident().equals("checked")){
            if(!incidentCheckbox.isChecked()){
                incidentCheckbox.toggle();
            }
        }else{
            if(incidentCheckbox.isChecked()){
                incidentCheckbox.toggle();
            }
        }
        if(dataRepository.getDefaultMapCheckboxViewRoadworks().equals("checked")){
            if(!roadworksCheckbox.isChecked()){
                roadworksCheckbox.toggle();
            }
        }else{
            if(roadworksCheckbox.isChecked()){
                roadworksCheckbox.toggle();
            }
        }
        if(dataRepository.getDefaultMapCheckboxViewPlannedRoadworks().equals("checked")){
            if(!plannedRoadworksCheckbox.isChecked()){
                plannedRoadworksCheckbox.toggle();
            }
        }else{
            if(plannedRoadworksCheckbox.isChecked()){
                plannedRoadworksCheckbox.toggle();
            }
        }
        if(dataRepository.getDefaultMapCheckboxViewFollowMe().equals("checked")){
            if(!followMeCheckbox.isChecked()){
                followMeCheckbox.toggle();
            }
        }else{
            if(followMeCheckbox.isChecked()){
                followMeCheckbox.toggle();
            }
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        Bundle mapViewBundle = outState.getBundle(MAPVIEW_BUNDLE_KEY);
        if (mapViewBundle == null) {
            mapViewBundle = new Bundle();
            outState.putBundle(MAPVIEW_BUNDLE_KEY, mapViewBundle);
        }

        mMapView.onSaveInstanceState(mapViewBundle);
    }

    @Override
    public void onResume() {
        super.onResume();
        mMapView.onResume();
    }

    @Override
    public void onStart() {
        super.onStart();
        mMapView.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
        mMapView.onStop();
    }

    @Override
    public void onMapReady(GoogleMap map) {
        this.map = map;
        //set the map to Scotland
        map.moveCamera(CameraUpdateFactory.newLatLngBounds(Scotland, 0));
        //change the default appearance of map marker snippet.
        map.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {

            @Override
            public View getInfoWindow(Marker arg0) {
                return null;
            }

            @Override
            public View getInfoContents(Marker marker) {

                LinearLayout info = new LinearLayout(GlobalContext.getContext());
                info.setOrientation(LinearLayout.VERTICAL);

                TextView title = new TextView(GlobalContext.getContext());
                title.setTextColor(Color.BLACK);
                title.setGravity(Gravity.CENTER);
                title.setTypeface(null, Typeface.BOLD);
                title.setText(marker.getTitle());

                TextView snippet = new TextView(GlobalContext.getContext());
                snippet.setTextColor(Color.GRAY);
                snippet.setText(marker.getSnippet());

                info.addView(title);
                info.addView(snippet);

                return info;
            }
        });
        redrawMap(false, false, false, false);
    }

    @Override
    public void onPause() {
        mMapView.onPause();
        super.onPause();
    }

    @Override
    public void onDestroy() {
        mMapView.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mMapView.onLowMemory();
    }
}
